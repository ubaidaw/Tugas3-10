<?php 
    require("db-con.php");

    $id = $_GET['id'];
    mysqli_query($connection, "DELETE FROM produk WHERE id=$id");

    header("Location: index.php");
?>