<?php 
    require("db-con.php");

    $produk = mysqli_query($connection, "SELECT * FROM produk");
    // mysqli_fetch_all($produk);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Produk</title>
</head>
<body>
<h1>DAFTAR PRODUK</h1>
<a href="insert.php">HALAMAN MEMASUKKAN PRODUK</a>
    <table border="2" cellpading="5" cellspacing="0" width="50%">
        <thead>
            <tr>
                <th>Nama Produk</th>
                <th>Keterangan</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php while($produks = mysqli_fetch_assoc($produk)){  ?>
            <tr>
                <td><?php echo $produks['nama_produk']; ?></td>
                <td><?php echo $produks['keterangan']; ?></td>
                <td><?php echo $produks['harga']; ?></td>
                <td><?php echo $produks['jumlah']; ?></td>
                <td>
                    <a href="update.php?id=<?php echo $produks['id'] ?>">Edit</a> | <a href="delete.php?id=<?php echo $produks['id'] ?>">Delete</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>