<?php

    require("db-con.php");

    $nama_produk = $_POST['nama_produk'];
    $keterangan = $_POST['keterangan_produk'];
    $harga = $_POST['harga_produk'];
    $jumlah = $_POST['jumlah_produk'];
    $produk_id = $_POST['produk_id'];
    
    mysqli_query($connection, "UPDATE produk SET nama_produk='$nama_produk', keterangan='$keterangan', harga=$harga, jumlah=$jumlah WHERE id=$produk_id");
    
    header("Location: index.php");
?>