<?php
    require("db-con.php");

    $data = mysqli_query($connection, "SELECT * FROM produk ");
    $produk = mysqli_fetch_all($data, MYSQLI_ASSOC);

    // var_dump($produk);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Data</title>
</head>
<body>
    <h1>MASUKKAN DATA PRODUK</h1>
    <form method="post" action="act_insert.php">
    <p>
        <label>Nama Produk</label><br>
        <input type="text" name="nama_produk">
    </p>
    <p>
        <label>Keterangan</label><br>
        <textarea name="keterangan" id="" cols="30" rows="10"></textarea>
    </p>
    <p>
        <label>Harga</label><br>
        <input type="text" name="harga_produk">
    </p>
    <p>
        <label>Jumlah</label><br>
        <input type="text" name="jumlah_produk">
    </p>
    <p>
        <input type="submit" value="Kirim">
    </p>
    </form>
</body>
</html>