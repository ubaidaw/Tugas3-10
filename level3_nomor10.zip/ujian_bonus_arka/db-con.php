<?php
    $connection = mysqli_connect("localhost","root","","arkademy");

    if(!$connection){
        echo "Gagal konek cuy!";
    }
?>