<?php
    require("db-con.php");

    $nama_produk = $_POST['nama_produk'];
    $keterangan = $_POST['keterangan'];
    $harga = $_POST['harga_produk'];
    $jumlah = $_POST['jumlah_produk'];


    mysqli_query($connection, "INSERT INTO produk(nama_produk,keterangan,harga,jumlah) VALUES ('$nama_produk','$keterangan',$harga,$jumlah)");

    header("Location: index.php");
?>