<?php
    require("db-con.php");

    $data = mysqli_query($connection, "SELECT * FROM produk ");
    $produk = mysqli_fetch_all($data, MYSQLI_ASSOC);

    // var_dump($produk);
    $id = $_GET['id'];
    $product = mysqli_query($connection, "SELECT * FROM produk WHERE id = $id");
    $product = mysqli_fetch_assoc($product);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data</title>
</head>
<body>
    <h1>MASUKKAN DATA PRODUK</h1>
    <form method="post" action="act_update.php">
    <p>
        <label>Nama Produk</label><br>
        <input type="text" name="nama_produk" value="<?php echo $product['nama_produk']; ?>">
    </p>
    <p>
        <label>Keterangan</label><br>
        <textarea name="keterangan_produk" id="" cols="30" rows="10"><?php echo $product['keterangan']; ?></textarea>
        
    </p>
    <p>
        <label>Harga</label><br>
        <input type="text" name="harga_produk" value="<?php echo $product['harga']; ?>">
    </p>
    <p>
        <label>Jumlah</label><br>
        <input type="text" name="jumlah_produk" value="<?php echo $product['jumlah']; ?>">
    </p>
    <p>
        <input type="hidden" name="produk_id" value="<?php echo $id ?>">
    </p>
    <p>
        <input type="submit" value="Kirim">
    </p>
    </form>
</body>
</html>